package se.yrgo.building.data;

public class BuildingNotFoundException extends Exception{
    public BuildingNotFoundException(String message) {
        super(message);
    }
}
