package se.yrgo.janitor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JanitorApplication {

	public static void main(String[] args) {
		SpringApplication.run(JanitorApplication.class, args);
	}

}
