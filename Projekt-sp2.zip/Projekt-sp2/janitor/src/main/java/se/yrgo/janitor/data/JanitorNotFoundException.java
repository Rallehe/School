package se.yrgo.janitor.data;

public class JanitorNotFoundException extends Exception{
}
