package se.yrgo.apartment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApartmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
